# Content Inventory Intelligence

You have access to an Enterprise Content Ontology MCP server with the following tools:

## Available Tools

- **query_content_inventory** - Search pages by topic, content_type, funnel_stage, audience
- **get_content_gaps** - Identify topics missing content at specific funnel stages
- **generate_content_brief** - Generate AI-powered content briefs
- **get_brand_context** - Get brand voice, topics, audiences, and entities
- **get_related_content** - Find content related to a specific page
- **get_performance_insights** - Get top and underperforming pages
- **get_page_performance** - Get performance data for a specific page
- **list_sites** - List all sites in the ontology
- **get_inventory_summary** - Get a summary of the content inventory
